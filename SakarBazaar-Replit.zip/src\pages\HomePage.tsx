import { useEffect, useState } from 'react';
import { EditorialCalendarStrip } from '../components/EditorialCalendarStrip';
import { HeroSection } from '../components/HeroSection';
import { IpoDeskSection } from '../components/IpoDeskSection';
import { IpoDeskSidebar } from '../components/IpoDeskSidebar';
import { LatestFeed } from '../components/LatestFeed';
import { MarketSnapshot } from '../components/MarketSnapshot';
import { useSakarBazaar } from '../context/SakarBazaarContext';
import {
  CALENDAR_SCHEDULE,
  HOMEPAGE_NEWS_CATEGORIES,
  IPO_ALL_RECORDS,
} from '../data/sampleData';
import type { HomepageNewsCategory } from '../types/sakarbazaar';
import { filterNewsItems } from '../utils/marketFormat';

export function HomePage() {
  const {
    copy,
    ui,
    bookmarks,
    watchlistIds,
    searchTerm,
    articlesCatalog,
    newsItems,
    marketData,
    marketLoading,
    toggleBookmark,
    toggleWatchlist,
    setSearchTerm,
  } = useSakarBazaar();

  const [selectedCategory, setSelectedCategory] = useState<HomepageNewsCategory>('All');
  const [shownCount, setShownCount] = useState(6);

  useEffect(() => {
    document.title = `SakarBazaar – ${ui.siteTagline}`;
  }, [ui.siteTagline]);

  const leadArticle = articlesCatalog.find((a) => a.isFeatured) ?? articlesCatalog[0];
  const secondaryArticle = articlesCatalog.find((a) => a.id !== leadArticle?.id);
  const filteredNews = filterNewsItems(newsItems, selectedCategory, searchTerm);
  const snapshotInstruments = [...marketData.indices, ...marketData.indicators];

  return (
    <>
      <main id="top" className="wrap layout">
        <div>
          {leadArticle && (
            <HeroSection
              leadArticle={leadArticle}
              secondaryArticle={secondaryArticle}
            />
          )}

          <LatestFeed
            title={copy.latest}
            categories={HOMEPAGE_NEWS_CATEGORIES}
            selectedCategory={selectedCategory}
            filteredItems={filteredNews}
            shownCount={shownCount}
            bookmarks={bookmarks}
            searchTerm={searchTerm}
            onSelectCategory={(cat) => {
              setSelectedCategory(cat);
              setShownCount(6);
            }}
            onLoadMore={() => setShownCount((prev) => prev + 6)}
            onToggleBookmark={toggleBookmark}
            onClearSearch={() => setSearchTerm('')}
          />
        </div>

        <aside>
          <MarketSnapshot
            title={copy.snapshot}
            benchmarks={snapshotInstruments}
            equities={marketData.equities}
            marketData={marketData}
            isLoading={marketLoading}
          />

          <IpoDeskSidebar records={IPO_ALL_RECORDS} />
        </aside>
      </main>

      <div className="wrap">
        <IpoDeskSection
          title={copy.ipodesk}
          records={IPO_ALL_RECORDS}
          watchlistIds={watchlistIds}
          onToggleWatchlist={toggleWatchlist}
        />

        <EditorialCalendarStrip calendarEvents={CALENDAR_SCHEDULE} />
      </div>
    </>
  );
}
