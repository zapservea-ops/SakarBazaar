import { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { PageBackNav } from '../components/PageBackNav';
import { useSakarBazaar } from '../context/SakarBazaarContext';
import { IPO_STATUS_LABELS } from '../data/i18n';
import { IPO_ALL_RECORDS } from '../data/sampleData';

export function IpoDetailPage() {
  const { slug } = useParams();
  const { lang, ui, watchlistIds, toggleWatchlist } = useSakarBazaar();

  const ipo = IPO_ALL_RECORDS.find((item) => item.slug === slug);

  useEffect(() => {
    document.title = ipo
      ? `${ipo.company} IPO – SakarBazaar`
      : `IPO Not Found – SakarBazaar`;
  }, [ipo]);

  if (!ipo) {
    return (
      <main className="wrap sb-page">
        <PageBackNav
          parentPath="/ipo"
          parentLabel={ui.ipoPageTitle}
          currentLabel="Not found"
        />
        <div className="card" style={{ padding: '24px' }}>
          <h1 style={{ font: '700 26px var(--serif)', margin: '0 0 8px' }}>
            {ui.noResultsTitle}
          </h1>
          <p style={{ color: 'var(--muted)', margin: '0 0 14px' }}>{ui.noResultsHint}</p>
          <Link to="/ipo" className="btn">
            {ui.ipoPageTitle}
          </Link>
        </div>
      </main>
    );
  }

  const isTracked = watchlistIds.has(ipo.id);

  return (
    <main id="top" className="wrap sb-page">
      <PageBackNav
        parentPath="/ipo"
        parentLabel={ui.ipoPageTitle}
        currentLabel={ipo.company}
      />

      <div className="sb-page-head">
        <div>
          <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap', marginBottom: '8px' }}>
            <span className="pill">{ipo.segment}</span>
            <span
              className={`pill ${
                ipo.verificationStatus === 'awaiting_verification' ? 'sb-pill-amber' : ''
              }`}
            >
              {IPO_STATUS_LABELS[lang][ipo.status]}
            </span>
          </div>
          <h1>{ipo.company}</h1>
          <p>{ipo.summary}</p>
        </div>
        <button
          type="button"
          className={isTracked ? 'btn ghost' : 'btn'}
          aria-pressed={isTracked}
          onClick={() => toggleWatchlist(ipo.id)}
        >
          {isTracked ? ui.saved : `+ ${ui.tableTrack}`}
        </button>
      </div>

      {ipo.verificationStatus === 'awaiting_verification' && (
        <div className="sb-sample-banner sb-verify-banner" role="note">
          <span>
            <strong>{ui.awaitingVerificationBadge}:</strong> Dates, price band, valuation, and
            financial metrics below come from user-supplied editorial material ({ipo.sourceName}).
            They are not yet confirmed by official SEBI DRHP/RHP or NSE/BSE exchange notices.
          </span>
          {ipo.relatedArticleSlug && (
            <Link
              to={`/article/${ipo.relatedArticleSlug}`}
              className="btn ghost"
              style={{ whiteSpace: 'nowrap' }}
            >
              Read editorial dispatch &amp; video →
            </Link>
          )}
        </div>
      )}

      <div className="sumgrid">
        <div className="card sum">
          <b>{ipo.issueSize ?? 'Not disclosed'}</b>
          <span>{ui.tableIssueSize}</span>
        </div>
        <div className="card sum">
          <b>{ipo.priceBand ?? 'Not disclosed'}</b>
          <span>{ui.tablePriceBand}</span>
        </div>
        <div className="card sum">
          <b>{ipo.upperBandValuation ?? 'Not disclosed'}</b>
          <span>Upper-band implied valuation</span>
        </div>
        <div className="card sum">
          <b>{ipo.offerType ?? 'Not disclosed'}</b>
          <span>{ui.tableOfferType}</span>
        </div>
      </div>

      <div className="sb-two-col">
        <div>
          {ipo.financialMetrics && ipo.financialMetrics.length > 0 && (
            <section className="card snap" style={{ marginBottom: '20px' }}>
              <div className="sec-h">
                <h2>Supplied Offer &amp; Financial Snapshot</h2>
                <span className="meta">{ui.awaitingVerificationBadge}</span>
              </div>
              {ipo.financialMetrics.map((row) => (
                <div className="row sb-snap-row" key={row.metric}>
                  <span>{row.metric}</span>
                  <strong className="num" style={{ textAlign: 'right' }}>
                    {row.value}
                  </strong>
                </div>
              ))}
            </section>
          )}

          {ipo.risksAndMonitorables && ipo.risksAndMonitorables.length > 0 && (
            <section className="card snap" style={{ marginBottom: '20px' }}>
              <div className="sec-h">
                <h2>Key Risks &amp; Monitorables</h2>
              </div>
              <ul style={{ margin: 0, paddingLeft: '20px' }}>
                {ipo.risksAndMonitorables.map((risk, idx) => (
                  <li key={idx} style={{ marginBottom: '8px' }}>
                    {risk}
                  </li>
                ))}
              </ul>
            </section>
          )}

          {ipo.verificationChecklist && ipo.verificationChecklist.length > 0 && (
            <section className="card snap" style={{ marginBottom: '20px' }}>
              <div className="sec-h">
                <h2>Verification Checklist</h2>
              </div>
              <ul style={{ margin: 0, paddingLeft: '20px' }}>
                {ipo.verificationChecklist.map((item, idx) => (
                  <li key={idx} style={{ marginBottom: '8px', color: 'var(--muted)' }}>
                    {item}
                  </li>
                ))}
              </ul>
            </section>
          )}

          <div className="sb-citation-list">
            {ipo.officialDocuments.map((doc) => (
              <div className="sb-citation-item" key={doc.id}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: '10px', flexWrap: 'wrap' }}>
                  <strong>{doc.label}</strong>
                  {doc.url && (
                    <a
                      href={doc.url}
                      target="_blank"
                      rel="noreferrer"
                      style={{ color: 'var(--teal)', fontWeight: 600 }}
                    >
                      {doc.portalName} ↗
                    </a>
                  )}
                </div>
                <div style={{ color: 'var(--muted)', fontSize: '13px', marginTop: '4px' }}>
                  {doc.note}
                </div>
              </div>
            ))}
          </div>
        </div>

        <aside>
          <section className="card snap">
            <div className="sec-h">
              <h2>Offer Terms &amp; Schedule</h2>
              <span className="meta">
                {ipo.verificationStatus === 'awaiting_verification' ? 'Unverified' : 'Verified'}
              </span>
            </div>
            <div className="row sb-snap-row">
              <span>Selling shareholder</span>
              <span style={{ textAlign: 'right' }}>{ipo.sellingShareholder ?? 'TBD'}</span>
            </div>
            <div className="row sb-snap-row">
              <span>Shares offered</span>
              <span className="num" style={{ textAlign: 'right' }}>
                {ipo.sharesOffered ?? 'TBD'} ({ipo.stakePercent ?? '–'})
              </span>
            </div>
            <div className="row sb-snap-row">
              <span>Proceeds recipient</span>
              <span style={{ textAlign: 'right' }}>{ipo.proceedsRecipient ?? 'TBD'}</span>
            </div>
            <div className="row sb-snap-row">
              <span>Proposed open date</span>
              <span className="num" style={{ textAlign: 'right' }}>
                {ipo.openDate ?? 'Pending official notice'}
              </span>
            </div>
            <div className="row sb-snap-row">
              <span>Proposed close date</span>
              <span className="num" style={{ textAlign: 'right' }}>
                {ipo.closeDate ?? 'Pending official notice'}
              </span>
            </div>
            <div className="row sb-snap-row">
              <span>Allotment date</span>
              <span className="num" style={{ textAlign: 'right' }}>
                {ipo.allotmentDate ?? 'Pending official RHP'}
              </span>
            </div>
            <div className="row sb-snap-row">
              <span>Listing date</span>
              <span className="num" style={{ textAlign: 'right' }}>
                {ipo.listingDate ?? 'Pending exchange notice'}
              </span>
            </div>
          </section>
        </aside>
      </div>
    </main>
  );
}
